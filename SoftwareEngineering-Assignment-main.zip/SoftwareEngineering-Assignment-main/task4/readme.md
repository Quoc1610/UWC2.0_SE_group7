This is the link to the Figma interface
https://www.figma.com/file/beSvoIW4sBZ9FpmNFP3tir/Untitled?node-id=0%3A1
