var messageBody = document.querySelector('.chat-messages');
      messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;

